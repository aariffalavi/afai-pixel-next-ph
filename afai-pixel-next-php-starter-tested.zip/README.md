# Afai Pixel — Next.js + PHP + MySQL Starter

A clean, isolated starter for the Afai Pixel redesign. This project does **not** modify `afaipixel.com` or `redesign.afaipixel.com`.

## Architecture
- `frontend/`: Next.js App Router + TypeScript + Tailwind CSS
- `api/`: PHP 8.3 REST API using PDO
- `database/schema.sql`: initial MySQL/MariaDB schema
- `deployment/`: deployment notes and environment examples

## Local development

### Frontend
Requires Node.js 20.9+.
```bash
cd frontend
cp .env.example .env.local
npm install
npm run dev
```
Open `http://localhost:3000`.

### PHP API
Run locally with PHP 8.3:
```bash
cd api
cp .env.example .env
php -S 127.0.0.1:8080 -t public
```
The health endpoint is `http://127.0.0.1:8080/health`.

Configure MySQL, then import `database/schema.sql`. Set `DB_HOST`, `DB_NAME`, `DB_USER`, and `DB_PASSWORD` in `api/.env` for your deployment environment. The sample API reads environment variables; the example `.env` file is documentation only and is not loaded automatically by PHP. Use your hosting environment's secret manager or a protected bootstrap loader.

## Important production steps
1. Keep production DNS unchanged while developing and testing.
2. Deploy the frontend to a staging hostname or temporary Hostinger Node.js app.
3. Deploy PHP API to a separate staging API hostname or protected directory.
4. Create a new database and database user with least-privilege access.
5. Set environment variables and allowed frontend origin.
6. Add rate limiting at the edge or application layer, SMTP delivery, spam protection, upload validation, monitoring, and backups.
7. Test mobile layouts, forms, API security, redirects, SEO metadata, sitemap, accessibility, and performance.
8. Only switch the public domain after written approval and a rollback plan.

## Current implementation status
This is a starter scaffold: the homepage, theme toggle, contact form UI, starter service/about/portfolio/blog/contact routes, admin placeholder, PHP health endpoint, validated contact endpoint, SEO sitemap/robots routes, and database schema are included. Full CMS CRUD, production authentication/RBAC, email delivery, uploads, analytics integrations, and deployment verification still need implementation and testing. Do not treat this scaffold as production-ready.
