# Hostinger staging deployment checklist

## Isolation and safety
- Keep `afaipixel.com` DNS and the existing production site unchanged.
- Use a separate staging hostname, for example `staging-next.afaipixel.com`, only after confirming DNS and Node.js app support.
- Use a separate API hostname such as `staging-api.afaipixel.com`.
- Create a new MySQL database and database user; do not reuse the live WordPress database.
- Keep all secrets out of Git and the frontend bundle.

## Frontend
1. Install dependencies and run `npm run build`.
2. Configure `NEXT_PUBLIC_API_BASE_URL` to the staging API URL.
3. Configure `NEXT_PUBLIC_SITE_URL` to the staging URL.
4. Deploy as a Node.js app using the runtime supported by the specific Hostinger plan.
5. Verify HTTPS, redirects, metadata, mobile menu and all links.

## API
1. Upload `api/` outside any public upload directory where possible; expose only `api/public/`.
2. Configure PHP 8.3 and PDO MySQL.
3. Set environment variables through Hostinger's supported configuration; never commit `.env`.
4. Set `APP_ALLOWED_ORIGIN` to the exact staging frontend origin.
5. Import `database/schema.sql` into a new staging database.
6. Test `/health` and submit a test contact enquiry.
7. Add rate limiting, SMTP email notifications, retention rules, monitoring and secure admin authentication before production use.

## Launch gate
Do not change public DNS until the owner approves after end-to-end tests, accessibility checks, SEO review, backup confirmation and rollback rehearsal.
