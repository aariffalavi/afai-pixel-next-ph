<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: no-referrer');

$allowedOrigin = getenv('APP_ALLOWED_ORIGIN') ?: 'http://localhost:3000';
$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
if ($origin === $allowedOrigin) {
    header('Access-Control-Allow-Origin: ' . $allowedOrigin);
    header('Vary: Origin');
}
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'OPTIONS') {
    http_response_code(204);
    exit;
}

function text_length(string $value): int {
    if (function_exists('mb_strlen')) return mb_strlen($value, 'UTF-8');
    $count = preg_match_all('/./us', $value, $matches);
    return $count === false ? strlen($value) : $count;
}

function respond(int $status, array $payload): never {
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

if ($path === '/health' && $method === 'GET') {
    respond(200, ['ok' => true, 'service' => 'Afai Pixel API', 'version' => '0.1.0']);
}

if ($path === '/contact' && $method === 'POST') {
    $raw = file_get_contents('php://input');
    $data = json_decode($raw ?: '', true);
    if (!is_array($data)) respond(400, ['ok' => false, 'error' => 'Invalid JSON body']);

    $name = trim((string)($data['name'] ?? ''));
    $email = trim((string)($data['email'] ?? ''));
    $message = trim((string)($data['message'] ?? ''));
    $company = trim((string)($data['company'] ?? ''));

    if ($name === '' || text_length($name) > 120) respond(422, ['ok' => false, 'error' => 'Enter a valid name']);
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || text_length($email) > 254) respond(422, ['ok' => false, 'error' => 'Enter a valid email']);
    if ($message === '' || text_length($message) > 5000) respond(422, ['ok' => false, 'error' => 'Enter a message up to 5000 characters']);

    // Honeypot: silently accept but do not persist when the hidden field is filled.
    if ($company !== '') respond(202, ['ok' => true, 'message' => 'Thank you.']);

    try {
        $dsn = sprintf('mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4',
            getenv('DB_HOST') ?: '127.0.0.1',
            getenv('DB_PORT') ?: '3306',
            getenv('DB_NAME') ?: 'afai_pixel'
        );
        $pdo = new PDO($dsn, getenv('DB_USER') ?: '', getenv('DB_PASSWORD') ?: '', [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
        $stmt = $pdo->prepare('INSERT INTO leads (name, email, message, status, created_at) VALUES (:name, :email, :message, :status, NOW())');
        $stmt->execute(['name' => $name, 'email' => $email, 'message' => $message, 'status' => 'new']);
        respond(201, ['ok' => true, 'message' => 'Thank you. Your enquiry has been received.']);
    } catch (Throwable $e) {
        error_log('Afai Pixel contact endpoint failed: ' . $e->getMessage());
        respond(503, ['ok' => false, 'error' => 'The enquiry could not be saved right now. Please try again later.']);
    }
}

respond(404, ['ok' => false, 'error' => 'Not found']);
