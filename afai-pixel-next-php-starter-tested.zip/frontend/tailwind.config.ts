import type { Config } from "tailwindcss";
const config: Config = {
  content: ["./src/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: {
    extend: {
      fontFamily: {
        sans: ["Arial", "Helvetica Neue", "sans-serif"],
      },
      boxShadow: {
        soft: "0 16px 50px rgba(17, 17, 17, 0.06)",
      },
    },
  },
  plugins: [],
};
export default config;
