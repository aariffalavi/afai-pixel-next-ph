import Link from "next/link";
import { LockKeyhole, ShieldAlert } from "lucide-react";

export const metadata = { title: "Admin sign-in" };

export default function AdminPage() {
  return (
    <main className="grid min-h-screen place-items-center px-6 py-16">
      <section className="w-full max-w-md rounded-[24px] border border-neutral-200 bg-white p-8 text-neutral-900 shadow-soft">
        <div className="mb-6 grid h-12 w-12 place-items-center rounded-xl bg-neutral-900 text-white"><LockKeyhole size={22} /></div>
        <p className="eyebrow">Afai Pixel / Administration</p>
        <h1 className="mt-3 text-3xl font-medium tracking-[-.05em]">Admin access</h1>
        <p className="mt-4 text-sm leading-6 text-neutral-600">The secure authentication flow is not enabled in this starter yet. This page is a placeholder and does not accept credentials.</p>
        <div className="mt-6 flex gap-3 rounded-xl bg-amber-50 p-4 text-sm text-amber-900"><ShieldAlert size={20} className="shrink-0" /><p>Do not enter a password here. Authentication, role checks and session protections must be implemented before this area is used.</p></div>
        <Link href="/" className="pill pill-dark mt-7">Return to website</Link>
      </section>
    </main>
  );
}
