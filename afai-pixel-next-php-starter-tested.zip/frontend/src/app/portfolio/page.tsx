import Link from "next/link";
import { ArrowLeft, ArrowUpRight } from "lucide-react";

export const metadata = {
  title: "Selected work",
  description: "A selection of project types and client partnerships. Case-study details will be added after review.",
};

export default function Page() {
  return (
    <main className="min-h-screen">
      <header className="container flex h-[88px] items-center justify-between border-b border-neutral-200/80">
        <Link href="/" className="text-xl font-semibold tracking-[-.06em]">afai pixel</Link>
        <Link href="/" className="inline-flex items-center gap-2 text-sm"><ArrowLeft size={15} /> Home</Link>
      </header>
      <section className="container py-20 md:py-28">
        <p className="eyebrow">Afai Pixel / Selected work</p>
        <h1 className="mt-5 max-w-4xl text-5xl font-medium tracking-[-.07em] md:text-7xl">Selected work</h1>
        <p className="mt-7 max-w-2xl text-lg leading-8 text-neutral-600">A selection of project types and client partnerships. Case-study details will be added after review.</p>
        <div className="mt-12 grid gap-3 md:grid-cols-2">
          <article key="Brand identity" className="rounded-[22px] border border-neutral-200 p-6"><h2 className="text-2xl font-medium tracking-[-.04em]">Brand identity</h2><p className="mt-3 text-sm leading-6 text-neutral-600">This section will be connected to the CMS as the full site build progresses.</p><Link href="/contact" className="mt-5 inline-flex items-center gap-2 text-sm font-semibold">Discuss a project <ArrowUpRight size={15} /></Link></article><article key="E-commerce" className="rounded-[22px] border border-neutral-200 p-6"><h2 className="text-2xl font-medium tracking-[-.04em]">E-commerce</h2><p className="mt-3 text-sm leading-6 text-neutral-600">This section will be connected to the CMS as the full site build progresses.</p><Link href="/contact" className="mt-5 inline-flex items-center gap-2 text-sm font-semibold">Discuss a project <ArrowUpRight size={15} /></Link></article><article key="Local services" className="rounded-[22px] border border-neutral-200 p-6"><h2 className="text-2xl font-medium tracking-[-.04em]">Local services</h2><p className="mt-3 text-sm leading-6 text-neutral-600">This section will be connected to the CMS as the full site build progresses.</p><Link href="/contact" className="mt-5 inline-flex items-center gap-2 text-sm font-semibold">Discuss a project <ArrowUpRight size={15} /></Link></article>
        </div>
        <Link href="/contact" className="pill pill-dark mt-10">Start a project <ArrowUpRight size={15} /></Link>
      </section>
    </main>
  );
}
