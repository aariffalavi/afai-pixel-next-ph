import Link from "next/link";
import { ArrowLeft, ArrowUpRight } from "lucide-react";

export const metadata = {
  title: "About Afai Pixel",
  description: "We bring design, technology and digital marketing together to help businesses move forward.",
};

export default function Page() {
  return (
    <main className="min-h-screen">
      <header className="container flex h-[88px] items-center justify-between border-b border-neutral-200/80">
        <Link href="/" className="text-xl font-semibold tracking-[-.06em]">afai pixel</Link>
        <Link href="/" className="inline-flex items-center gap-2 text-sm"><ArrowLeft size={15} /> Home</Link>
      </header>
      <section className="container py-20 md:py-28">
        <p className="eyebrow">Afai Pixel / About Afai Pixel</p>
        <h1 className="mt-5 max-w-4xl text-5xl font-medium tracking-[-.07em] md:text-7xl">About Afai Pixel</h1>
        <p className="mt-7 max-w-2xl text-lg leading-8 text-neutral-600">We bring design, technology and digital marketing together to help businesses move forward.</p>
        <div className="mt-12 grid gap-3 md:grid-cols-2">
          <article key="Our approach" className="rounded-[22px] border border-neutral-200 p-6"><h2 className="text-2xl font-medium tracking-[-.04em]">Our approach</h2><p className="mt-3 text-sm leading-6 text-neutral-600">This section will be connected to the CMS as the full site build progresses.</p><Link href="/contact" className="mt-5 inline-flex items-center gap-2 text-sm font-semibold">Discuss a project <ArrowUpRight size={15} /></Link></article><article key="Our process" className="rounded-[22px] border border-neutral-200 p-6"><h2 className="text-2xl font-medium tracking-[-.04em]">Our process</h2><p className="mt-3 text-sm leading-6 text-neutral-600">This section will be connected to the CMS as the full site build progresses.</p><Link href="/contact" className="mt-5 inline-flex items-center gap-2 text-sm font-semibold">Discuss a project <ArrowUpRight size={15} /></Link></article><article key="Our values" className="rounded-[22px] border border-neutral-200 p-6"><h2 className="text-2xl font-medium tracking-[-.04em]">Our values</h2><p className="mt-3 text-sm leading-6 text-neutral-600">This section will be connected to the CMS as the full site build progresses.</p><Link href="/contact" className="mt-5 inline-flex items-center gap-2 text-sm font-semibold">Discuss a project <ArrowUpRight size={15} /></Link></article>
        </div>
        <Link href="/contact" className="pill pill-dark mt-10">Start a project <ArrowUpRight size={15} /></Link>
      </section>
    </main>
  );
}
