import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: {
    default: "Afai Pixel — Make your ideas a reality",
    template: "%s | Afai Pixel",
  },
  description:
    "Afai Pixel is a creative design, web development and digital marketing agency helping businesses build memorable brands and digital experiences.",
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000"),
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
