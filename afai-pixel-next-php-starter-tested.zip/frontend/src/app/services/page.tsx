import Link from "next/link";
import { ArrowLeft, ArrowUpRight } from "lucide-react";

export const metadata = {
  title: "Services",
  description: "A connected set of creative and digital services.",
};

export default function Page() {
  return (
    <main className="min-h-screen">
      <header className="container flex h-[88px] items-center justify-between border-b border-neutral-200/80">
        <Link href="/" className="text-xl font-semibold tracking-[-.06em]">afai pixel</Link>
        <Link href="/" className="inline-flex items-center gap-2 text-sm"><ArrowLeft size={15} /> Home</Link>
      </header>
      <section className="container py-20 md:py-28">
        <p className="eyebrow">Afai Pixel / Services</p>
        <h1 className="mt-5 max-w-4xl text-5xl font-medium tracking-[-.07em] md:text-7xl">Services</h1>
        <p className="mt-7 max-w-2xl text-lg leading-8 text-neutral-600">A connected set of creative and digital services.</p>
        <div className="mt-12 grid gap-3 md:grid-cols-2">
          <article key="Brand identity & graphic design" className="rounded-[22px] border border-neutral-200 p-6"><h2 className="text-2xl font-medium tracking-[-.04em]">Brand identity & graphic design</h2><p className="mt-3 text-sm leading-6 text-neutral-600">This section will be connected to the CMS as the full site build progresses.</p><Link href="/contact" className="mt-5 inline-flex items-center gap-2 text-sm font-semibold">Discuss a project <ArrowUpRight size={15} /></Link></article><article key="Web design & development" className="rounded-[22px] border border-neutral-200 p-6"><h2 className="text-2xl font-medium tracking-[-.04em]">Web design & development</h2><p className="mt-3 text-sm leading-6 text-neutral-600">This section will be connected to the CMS as the full site build progresses.</p><Link href="/contact" className="mt-5 inline-flex items-center gap-2 text-sm font-semibold">Discuss a project <ArrowUpRight size={15} /></Link></article><article key="Search engine optimisation" className="rounded-[22px] border border-neutral-200 p-6"><h2 className="text-2xl font-medium tracking-[-.04em]">Search engine optimisation</h2><p className="mt-3 text-sm leading-6 text-neutral-600">This section will be connected to the CMS as the full site build progresses.</p><Link href="/contact" className="mt-5 inline-flex items-center gap-2 text-sm font-semibold">Discuss a project <ArrowUpRight size={15} /></Link></article><article key="Social media marketing" className="rounded-[22px] border border-neutral-200 p-6"><h2 className="text-2xl font-medium tracking-[-.04em]">Social media marketing</h2><p className="mt-3 text-sm leading-6 text-neutral-600">This section will be connected to the CMS as the full site build progresses.</p><Link href="/contact" className="mt-5 inline-flex items-center gap-2 text-sm font-semibold">Discuss a project <ArrowUpRight size={15} /></Link></article><article key="Google Ads & paid media" className="rounded-[22px] border border-neutral-200 p-6"><h2 className="text-2xl font-medium tracking-[-.04em]">Google Ads & paid media</h2><p className="mt-3 text-sm leading-6 text-neutral-600">This section will be connected to the CMS as the full site build progresses.</p><Link href="/contact" className="mt-5 inline-flex items-center gap-2 text-sm font-semibold">Discuss a project <ArrowUpRight size={15} /></Link></article><article key="Video editing & animation" className="rounded-[22px] border border-neutral-200 p-6"><h2 className="text-2xl font-medium tracking-[-.04em]">Video editing & animation</h2><p className="mt-3 text-sm leading-6 text-neutral-600">This section will be connected to the CMS as the full site build progresses.</p><Link href="/contact" className="mt-5 inline-flex items-center gap-2 text-sm font-semibold">Discuss a project <ArrowUpRight size={15} /></Link></article><article key="Hosting & business email" className="rounded-[22px] border border-neutral-200 p-6"><h2 className="text-2xl font-medium tracking-[-.04em]">Hosting & business email</h2><p className="mt-3 text-sm leading-6 text-neutral-600">This section will be connected to the CMS as the full site build progresses.</p><Link href="/contact" className="mt-5 inline-flex items-center gap-2 text-sm font-semibold">Discuss a project <ArrowUpRight size={15} /></Link></article><article key="Strategy & consultation" className="rounded-[22px] border border-neutral-200 p-6"><h2 className="text-2xl font-medium tracking-[-.04em]">Strategy & consultation</h2><p className="mt-3 text-sm leading-6 text-neutral-600">This section will be connected to the CMS as the full site build progresses.</p><Link href="/contact" className="mt-5 inline-flex items-center gap-2 text-sm font-semibold">Discuss a project <ArrowUpRight size={15} /></Link></article>
        </div>
        <Link href="/contact" className="pill pill-dark mt-10">Start a project <ArrowUpRight size={15} /></Link>
      </section>
    </main>
  );
}
