import {
  ArrowDownRight, ArrowUpRight, Asterisk, BadgeCheck, Code2, Layers3,
  Megaphone, Play, Sparkles, WandSparkles,
} from "lucide-react";
import ThemeToggle from "@/components/ThemeToggle";
import ContactForm from "@/components/ContactForm";

const services = [
  { icon: Layers3, number: "01", title: "Brand & graphic design", text: "Distinctive identities, campaign creative and packaging built to be remembered." },
  { icon: Code2, number: "02", title: "Websites & digital products", text: "Thoughtful websites and digital experiences that make complex things feel simple." },
  { icon: Megaphone, number: "03", title: "Digital marketing", text: "Connected SEO, paid media and social campaigns focused on meaningful growth." },
  { icon: WandSparkles, number: "04", title: "Video & motion", text: "Clear, compelling motion and content that earns attention and tells your story." },
];

const projects = [
  { category: "E-commerce · Europe", title: "Global Supermarket", description: "A clearer digital shopping experience for a cross-border grocery brand.", initials: "GS", tone: "bg-[#e9e5dd]" },
  { category: "Home & interiors · UK", title: "Surface Stone", description: "A premium digital presence built around materials, craft and conversion.", initials: "SS", tone: "bg-[#e2e3df]" },
  { category: "Services · Australia", title: "J Junk Rubbish Removal", description: "A local-service experience designed to make enquiries straightforward.", initials: "JJ", tone: "bg-[#e8e2dc]" },
];

export default function HomePage() {
  return (
    <main>
      <header className="container flex h-[88px] items-center justify-between border-b border-neutral-200/80">
        <a href="#" className="flex items-center gap-3" aria-label="Afai Pixel home">
          <span className="grid h-10 w-10 place-items-center rounded-xl bg-neutral-900 text-white"><Asterisk size={28} strokeWidth={1.6} /></span>
          <span><span className="block text-[19px] font-semibold tracking-[-0.06em]">afai pixel</span><span className="block text-[9px] font-bold tracking-[.18em] text-neutral-500">CREATIVE DIGITAL STUDIO</span></span>
        </a>
        <nav className="hidden items-center gap-8 text-[13px] text-neutral-600 md:flex" aria-label="Main navigation">
          <a className="hover:text-black" href="#services">Services</a>
          <a className="hover:text-black" href="#work">Selected work</a>
          <a className="hover:text-black" href="#about">About</a>
          <a className="hover:text-black" href="#contact">Contact</a>
        </nav>
        <div className="flex items-center gap-3">
          <ThemeToggle />
          <a href="#contact" className="pill pill-dark hidden sm:inline-flex">Start a project <ArrowUpRight size={15} /></a>
        </div>
      </header>

      <section className="container pb-20 pt-16 md:pb-28 md:pt-24">
        <div className="mb-7 flex items-center gap-3"><span className="h-px w-8 bg-neutral-400" /><p className="eyebrow">Independent creative & digital agency</p></div>
        <h1 className="display max-w-[1050px]">Make your ideas<br />a <span className="text-neutral-400">reality.</span></h1>
        <div className="mt-9 grid gap-8 md:grid-cols-[1fr_340px] md:items-end">
          <p className="max-w-[560px] text-lg leading-8 text-neutral-600">We build memorable brands, thoughtful websites and digital experiences that help ambitious businesses move forward.</p>
          <div className="flex flex-wrap gap-3 md:justify-end">
            <a className="pill pill-dark" href="#work">Explore our work <ArrowUpRight size={15} /></a>
            <a className="pill pill-light" href="#services">What we do <ArrowDownRight size={15} /></a>
          </div>
        </div>

        <div className="relative mt-14 overflow-hidden rounded-[28px] bg-[#191a19] p-6 text-white shadow-soft md:mt-20 md:p-10">
          <div className="absolute -right-12 -top-24 h-72 w-72 rounded-full border border-white/15 md:right-20 md:top-[-145px] md:h-[440px] md:w-[440px]" />
          <div className="absolute -right-2 -top-14 h-56 w-56 rounded-full border border-white/10 md:right-32 md:top-[-100px] md:h-[320px] md:w-[320px]" />
          <div className="relative grid min-h-[250px] gap-10 md:grid-cols-[1fr_300px] md:items-end">
            <div><p className="eyebrow !text-neutral-400">Strategy meets imagination</p><h2 className="mt-5 max-w-[640px] text-3xl font-medium leading-tight tracking-[-.055em] md:text-5xl">Good design gets noticed. Great experiences move business forward.</h2></div>
            <div className="flex items-end justify-between md:justify-end md:gap-5"><div><p className="text-sm text-neutral-300">One connected team.</p><p className="mt-1 text-sm text-neutral-300">Ideas made tangible.</p></div><span className="grid h-14 w-14 place-items-center rounded-full bg-white text-black"><Play size={18} fill="currentColor" /></span></div>
          </div>
        </div>
      </section>

      <section id="services" className="bg-white py-20 md:py-28">
        <div className="container">
          <div className="flex flex-col justify-between gap-5 md:flex-row md:items-end"><div><p className="eyebrow">What we bring together</p><h2 className="mt-4 text-4xl font-medium tracking-[-.06em] md:text-6xl">Creative thinking.<br />Practical outcomes.</h2></div><p className="max-w-sm text-sm leading-7 text-neutral-600">From the first idea to the final click, we bring the right disciplines together to create a more cohesive digital presence.</p></div>
          <div className="mt-12 grid gap-3 md:grid-cols-2">
            {services.map(({ icon: Icon, number, title, text }) => <article key={number} className="group rounded-[22px] border border-neutral-200 p-6 transition-colors hover:bg-[#f8f7f5] md:p-8"><div className="flex items-center justify-between"><span className="text-xs text-neutral-400">{number} / 04</span><Icon size={22} strokeWidth={1.5} /></div><h3 className="mt-12 text-2xl font-medium tracking-[-.045em]">{title}</h3><p className="mt-3 max-w-md text-sm leading-6 text-neutral-600">{text}</p><a href="#contact" className="mt-7 inline-flex items-center gap-2 text-sm font-semibold">Discover service <ArrowUpRight size={15} /></a></article>)}
          </div>
        </div>
      </section>

      <section id="work" className="container py-20 md:py-28">
        <div className="flex items-end justify-between gap-5"><div><p className="eyebrow">Selected collaborations</p><h2 className="mt-4 text-4xl font-medium tracking-[-.06em] md:text-6xl">Work with purpose.</h2></div><a href="#contact" className="hidden items-center gap-2 text-sm md:inline-flex">Discuss a project <ArrowUpRight size={15} /></a></div>
        <div className="mt-12 grid gap-5 md:grid-cols-3">
          {projects.map((project) => <article key={project.title}><div className={`relative grid aspect-[4/3] place-items-center overflow-hidden rounded-[22px] ${project.tone}`}><div className="absolute inset-5 rounded-[16px] border border-black/10" /><span className="text-6xl font-semibold tracking-[-.09em] text-black/75">{project.initials}</span><span className="absolute bottom-7 right-7 grid h-10 w-10 place-items-center rounded-full bg-white/80"><ArrowUpRight size={17} /></span></div><p className="eyebrow mt-5">{project.category}</p><h3 className="mt-2 text-xl font-medium tracking-[-.04em]">{project.title}</h3><p className="mt-2 text-sm leading-6 text-neutral-600">{project.description}</p></article>)}
        </div>
        <p className="mt-6 text-xs text-neutral-500">Portfolio cards are illustrative starter content. Replace with approved client imagery and verified case-study details before launch.</p>
      </section>

      <section id="about" className="bg-[#eeede9] py-20 md:py-28">
        <div className="container grid gap-10 md:grid-cols-[.8fr_1.2fr]"><div><p className="eyebrow">A little about us</p><span className="mt-6 inline-grid h-14 w-14 place-items-center rounded-2xl bg-black text-white"><BadgeCheck size={25} /></span></div><div><h2 className="text-4xl font-medium leading-tight tracking-[-.06em] md:text-6xl">A creative partner for the next chapter of your business.</h2><p className="mt-7 max-w-2xl text-base leading-8 text-neutral-600">Afai Pixel brings design, technology and digital marketing together to help brands communicate clearly and grow with confidence. We focus on purposeful creative work, useful digital experiences and long-term partnerships.</p><div className="mt-8 flex items-center gap-2 text-sm font-semibold"><Sparkles size={16} /> Make your ideas a reality.</div></div></div>
      </section>

      <section id="contact" className="container py-20 md:py-28">
        <div className="rounded-[28px] bg-[#171817] px-6 py-12 text-white md:px-12 md:py-16">
          <p className="eyebrow !text-neutral-400">Have something in mind?</p><div className="mt-5 grid gap-8 md:grid-cols-[1fr_280px] md:items-end"><h2 className="text-4xl font-medium tracking-[-.065em] md:text-6xl">Let’s make<br />something matter.</h2><div><p className="text-sm leading-6 text-neutral-300">Tell us where you want to go. We’ll help you map the next steps.</p><ContactForm /></div></div>
        </div>
      </section>

      <footer className="container flex flex-col gap-5 border-t border-neutral-200 py-8 text-xs text-neutral-500 sm:flex-row sm:items-center sm:justify-between"><span>© {new Date().getFullYear()} Afai Pixel. Make your ideas a reality.</span><div className="flex gap-5"><a href="#services">Services</a><a href="#work">Work</a><a href="#contact">Contact</a></div></footer>
    </main>
  );
}
