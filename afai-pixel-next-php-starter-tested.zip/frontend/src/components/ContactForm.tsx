"use client";

import { FormEvent, useState } from "react";
import { ArrowUpRight, CheckCircle2, LoaderCircle } from "lucide-react";

export default function ContactForm() {
  const [status, setStatus] = useState<"idle" | "sending" | "success" | "error">("idle");
  const [error, setError] = useState("");

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setStatus("sending");
    setError("");
    const formElement = event.currentTarget;
    const form = new FormData(formElement);
    const payload = {
      name: String(form.get("name") || ""),
      email: String(form.get("email") || ""),
      message: String(form.get("message") || ""),
      company: String(form.get("company") || ""),
    };
    try {
      const base = process.env.NEXT_PUBLIC_API_BASE_URL;
      if (!base) throw new Error("The enquiry service is not configured yet.");
      const response = await fetch(`${base.replace(/\/$/, "")}/contact`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const result = await response.json();
      if (!response.ok || !result.ok) throw new Error(result.error || "Please try again later.");
      setStatus("success");
      formElement.reset();
    } catch (e) {
      setStatus("error");
      setError(e instanceof Error ? e.message : "Something went wrong. Please try again.");
    }
  }

  if (status === "success") {
    return <div className="flex items-start gap-3 rounded-2xl border border-green-200 bg-green-50 p-5 text-green-900"><CheckCircle2 size={22} /><div><p className="font-semibold">Thank you for reaching out.</p><p className="mt-1 text-sm">Your enquiry has been received.</p></div></div>;
  }

  return (
    <form onSubmit={submit} className="mt-7 space-y-4">
      <div className="grid gap-4 sm:grid-cols-2">
        <label className="block text-sm">Your name
          <input required name="name" maxLength={120} autoComplete="name" className="mt-2 w-full rounded-xl border border-white/20 bg-white/5 px-4 py-3 text-white outline-none placeholder:text-neutral-500 focus:border-white/60" placeholder="Name" />
        </label>
        <label className="block text-sm">Email address
          <input required type="email" name="email" maxLength={254} autoComplete="email" className="mt-2 w-full rounded-xl border border-white/20 bg-white/5 px-4 py-3 text-white outline-none placeholder:text-neutral-500 focus:border-white/60" placeholder="you@company.com" />
        </label>
      </div>
      <label className="block text-sm">Tell us about your project
        <textarea required name="message" maxLength={5000} rows={4} className="mt-2 w-full resize-y rounded-xl border border-white/20 bg-white/5 px-4 py-3 text-white outline-none placeholder:text-neutral-500 focus:border-white/60" placeholder="What would you like to create?" />
      </label>
      <label aria-hidden="true" className="absolute -left-[10000px] top-auto h-px w-px overflow-hidden">Company
        <input tabIndex={-1} autoComplete="off" name="company" />
      </label>
      {status === "error" && <p role="alert" className="text-sm text-red-300">{error}</p>}
      <button disabled={status === "sending"} className="pill bg-white text-black disabled:opacity-60" type="submit">
        {status === "sending" ? <><LoaderCircle size={16} className="animate-spin" /> Sending…</> : <>Send enquiry <ArrowUpRight size={15} /></>}
      </button>
      <p className="text-xs leading-5 text-neutral-400">Please do not include passwords or other sensitive information in this form.</p>
    </form>
  );
}
