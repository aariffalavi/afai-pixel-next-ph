"use client";

import { Moon, Sun } from "lucide-react";
import { useEffect, useState } from "react";

export default function ThemeToggle() {
  const [dark, setDark] = useState(false);
  useEffect(() => {
    const saved = window.localStorage.getItem("afai-theme");
    if (saved === "dark") setDark(true);
  }, []);
  useEffect(() => {
    document.documentElement.dataset.theme = dark ? "dark" : "light";
    window.localStorage.setItem("afai-theme", dark ? "dark" : "light");
  }, [dark]);
  return (
    <button
      type="button"
      aria-label={dark ? "Switch to light theme" : "Switch to dark theme"}
      onClick={() => setDark((value) => !value)}
      className="grid h-10 w-10 place-items-center rounded-full border border-neutral-200 hover:bg-neutral-100"
    >
      {dark ? <Sun size={17} /> : <Moon size={17} />}
    </button>
  );
}
